public class Test8{

	public static void main(String[] args){
byte x = 100;

short y = 15000;

int z = 120121;

long a = 1000000000000000L;

double b = 125.0000000000d;

String c = "Sai";


 System.out.println(x);
System.out.println(y);
System.out.println(z);
System.out.println(a);
System.out.println(b); 
System.out.println(c); 

}
}