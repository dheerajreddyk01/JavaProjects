public class Test6{

	public static void main(String[] args){

int studentAge = 30;
String studentName = "Sai";
char studentGrade = 'a';
float studentPercentage = 90.62f;


 System.out.println("Age of Student is: " + studentAge);
 System.out.println("Name of the Student: " + studentName);
 System.out.println("Grede Secure by student: " + studentGrade);
 System.out.println("Student Percentage is: " + studentPercentage);

}
}