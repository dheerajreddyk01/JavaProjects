public class Test{

	public static void main(String[] args){

String first = "Varun";


 System.out.println(first);

}
}