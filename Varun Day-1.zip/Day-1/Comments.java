public class Comments{
public static void main(String[] args){
System.out.println(3);
// System.out.print(20 / 6); 
System.out.println(9 + 3); // We are doing Addition Operation here.
System.out.println(9 * 3);
/* System.out.println(9 * 3);
 System.out.println(9 * 3); */
}
}