public class Test2{

public static void main(String[] args){

final int value = 30;

 // value = 40;

System.out.println(value);

}
}