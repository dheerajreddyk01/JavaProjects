public class Test3{

public static void main(String[] args){

int myNum = 30;
 
String country = "INDIA";

float myDec= 23.5f;

boolean myCondition = false;

char myWord = 'v'; 

final int value = 30;


System.out.println(myNum);
System.out.println(country);
System.out.println(myDec);
System.out.println(myCondition);
System.out.println(myWord);
System.out.println(value);

}
}