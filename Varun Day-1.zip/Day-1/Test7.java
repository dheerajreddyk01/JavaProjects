public class Test7{

	public static void main(String[] args){

int length = 4;
int width = 7;

int area = length * width;

    
    System.out.println("Length is: " + length);
    System.out.println("Width is: " + width);
    System.out.println("Area of the rectangle is: " + area);

}
}

