public class Test9
{

	public static void main(String[] args){

int items = 23;

float itemCost = 50.23f;

String personName = "Varun";

char currency = '$';

float totalCost = items * itemCost;

System.out.println(personName + " bill: " + currency + totalCost);

}
}