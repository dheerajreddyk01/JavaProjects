public class Test1 {

public static void main(String[] args){

int value = 30;
value = 40;

System.out.println(value);

}
}