public class Test5{

	public static void main(String[] args){


int x = 10, y = 60, z = 30;

int v = x + y + z;

 // System.out.println(fullName);
 
 System.out.println(v);

}
}