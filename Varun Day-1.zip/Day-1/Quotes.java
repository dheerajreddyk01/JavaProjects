public class Quotes{
public static void main(String[] args){
System.out.print("Hello World");
System.out.println("Sai");
}
}