public class Variables{

	public static void main(String[] args){
int id = 01;

System.out.println(id);

// System.out.println("Sai");

}
}