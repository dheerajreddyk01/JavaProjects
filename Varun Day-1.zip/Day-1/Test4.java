public class Test4{

	public static void main(String[] args){


String firstName = "Varun Sree";
String lastName = "Gundapuneni";
String fullName = firstName + lastName; 

int x = 10;
int y = 60;
int z = x+y;

 System.out.println(fullName);
 System.out.println(z);

}
}